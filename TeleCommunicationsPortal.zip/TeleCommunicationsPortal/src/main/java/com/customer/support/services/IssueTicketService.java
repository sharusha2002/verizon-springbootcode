package com.customer.support.services;

public interface IssueTicketService {
	public void generateTicket(String userIssueId);
}
