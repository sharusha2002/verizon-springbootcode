package com.waleed.verizon.training;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class AppTest{
	
	
	@BeforeAll
	static void callAtBeginning() {
		System.out.println("callAtBeginning called...");
	}
	
	
	@AfterAll
	static void callAtEnd() {
		System.out.println("callAtEnd called...");
	}
	
	@BeforeEach
	void callBeforeEachTest() {
		System.out.println("beforeEach called...");
	}
	
	@AfterEach
	void callAfterEachTest() {
		System.out.println("afterEach called...");
	}
	
	
	
	@Test
	void testDivideNumbers() {
//		fail("The test just failed...");
		
		int expected = 20;
		
		
		App app = new App();
//		int actual = app.divideNumbers(100, 0);
		
//		assertNotEquals(expected, actual, "Must have been equal");
		
//		assertNotNull(app.getObjectValue());
		
		assertAll(
//				() -> assertEquals(expected, actual),
//				() -> assertEquals(20, actual),
//				() -> assertEquals(30, actual, "Values not equal"),
() -> assertThrows(ArithmeticException.class, () -> assertEquals(2, app.divideNumbers(100, 0)))
				);
	
	}
	
	
	@ParameterizedTest
	@ValueSource(strings = {"sanjana", "madam", "gokul"})
	void testCheckForPalindrome(String value) {
		assertEquals(true, new App().checkForPalindrome(value));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}