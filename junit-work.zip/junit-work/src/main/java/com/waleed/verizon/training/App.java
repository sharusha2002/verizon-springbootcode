package com.waleed.verizon.training;

public class App {
	int divideNumbers(int firstNum, int secondNum) {
		return firstNum / secondNum;

	}

	boolean checkForPalindrome(String value) {
		if (value.equals("madam"))
			return true;
		else
			return false;
	}

	App getObjectValue() {
		return null;
	}
}
