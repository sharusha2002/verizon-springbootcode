package org.verizon;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.ArrayList;

public class App
{
    public static void main( String[] args )
    {
        SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Laptop.class)
                .buildSessionFactory();

        Session currentSession = sessionFactory.getCurrentSession();

        try{
//            Add a new Laptop and get the details back

//            1. Create a new Laptop object
//            Laptop laptop = new Laptop("Wiao", "Sony", 32);

//            2. Begin the transaction
            currentSession.beginTransaction();

//            3. Save the laptop
//            currentSession.save(laptop);

//            System.out.println("Laptop id : " + laptop.getId());

            Laptop readLaptop = currentSession.get(Laptop.class, 2);

            System.out.println("Laptop details : " + readLaptop);

//            4. Commit the transaction
               currentSession.getTransaction().commit();

            //System.out.println("New Laptop details registered...");
        }finally{
                currentSession.close();
        }
    }
}
