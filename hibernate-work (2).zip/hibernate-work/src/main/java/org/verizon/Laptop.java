package org.verizon;

import jakarta.persistence.*;

@Entity
@Table(name="laptop")
public class Laptop {

    Laptop(){

    }

    @Override
    public String toString() {
        return "Laptop{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", manufacturer='" + manufacturer + '\'' +
                ", ram=" + ram +
                '}';
    }

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    @Column(name = "name")
    String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public Integer getRam() {
        return ram;
    }

    public void setRam(Integer ram) {
        this.ram = ram;
    }

    public Laptop(String name, String manufacturer, Integer ram) {
        this.name = name;
        this.manufacturer = manufacturer;
        this.ram = ram;
    }

    @Column(name = "manufacturer")
    String manufacturer;

    @Column(name = "ram")
    Integer ram;

}
